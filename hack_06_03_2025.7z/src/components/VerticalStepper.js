import React, { useState } from 'react';
import {
  Stepper,
  Step,
  StepLabel,
  StepContent,
  Button,
  Paper,
  Typography,
  Box
} from '@mui/material';


import ConfigurationModal from './ConfigurationModal';

import DocSearchForm from './DocSearchForm';
import CustomStepIcon from './CustomStepsIcon';
import ExtractMetrics from './ExtractMetrics';

const steps = [
  { label: 'Configure Attributes', content: <ConfigurationModal></ConfigurationModal> },
  { label: 'Download Data', content: <DocSearchForm></DocSearchForm> },
  { label: 'Data Extraction', content:  <ExtractMetrics></ExtractMetrics>},
  { label: 'Reporting & Presentation', content:  <ConfigurationModal></ConfigurationModal> }
];

export default function VerticalStepper() {
  const [activeStep, setActiveStep] = useState(0);

  const handleNext = () => {
    setActiveStep((prev) => prev + 1);
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
  };

  const handleReset = () => {
    setActiveStep(0);
  };

  return (
    <Box sx={{ }}>
      <Stepper activeStep={activeStep} orientation="vertical">
        {steps.map((step, index) => (
          <Step key={step.label}>
            <StepLabel StepIconComponent={CustomStepIcon}>
              <Typography fontWeight={600}>{step.label}</Typography>
            </StepLabel>
            <StepContent>
              <Box sx={{ mb: 2 }}>
                {step.content}
                <Box sx={{ mt: 2 }}>
                  <Button
                    variant="contained"
                    onClick={handleNext}
                    sx={{ mt: 1, mr: 1 }}
                    disabled={activeStep === steps.length - 1}
                  >
                    {index === steps.length - 1 ? 'Finish' : 'Next'}
                  </Button>
                  <Button
                    disabled={activeStep === 0}
                    onClick={handleBack}
                    sx={{ mt: 1 }}
                  >
                    Back
                  </Button>
                </Box>
              </Box>
            </StepContent>
          </Step>
        ))}
      </Stepper>

      {activeStep === steps.length && (
        <Paper square elevation={0} sx={{ p: 3 }}>
          <Typography>🎉 All steps completed — you're done!</Typography>
          <Button onClick={handleReset} sx={{ mt: 2 }}>Reset</Button>
        </Paper>
      )}
    </Box>
  );
}