import React, { useContext, useState } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,

  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  Box,
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  stepConnectorClasses,
  CardMedia
} from '@mui/material';


import HomeIcon from '@mui/icons-material/Home';
import InfoIcon from '@mui/icons-material/Info';
import ArticleIcon from '@mui/icons-material/Article';
import DownloadIcon from '@mui/icons-material/Download';
import TableChartIcon from '@mui/icons-material/TableChart';
import ChatIcon from '@mui/icons-material/Chat';
import AssessmentIcon from '@mui/icons-material/Assessment';
import { styled } from '@mui/material/styles';
import SettingsIcon from '@mui/icons-material/Settings';
import ConfigurationModal from './ConfigurationModal';
import ThemeContext from './ThemeContext';
import tempImge from "./logo.png"
const drawerWidth = 240;

const steps = [
  'Data Collection',
  'Data Extraction',
  'Commentary Analysis',
  'Reporting & Presentation'
];



const ColorlibConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 22,
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage:
        'linear-gradient(95deg,#4caf50 0%,#81c784 50%,#66bb6a 100%)',
    },
  },
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage:
        'linear-gradient(136deg,rgb(219, 145, 60) 0%,rgb(235, 160, 47) 50%,rgb(219, 137, 82) 100%)',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: '#eaeaf0',
    borderRadius: 1,
  },
}));

const ColorlibStepIconRoot = styled('div')(({ theme, ownerState }) => ({

  backgroundColor: '#ccc',
  zIndex: 1,
  color: '#fff',
  width: 40,
  height: 40,
  display: 'flex',
  borderRadius: '50%',
  justifyContent: 'center',
  alignItems: 'center',
  ...(ownerState.completed && {
    backgroundImage:
      'linear-gradient(136deg,rgb(18, 133, 21) 0%,rgb(15, 161, 22) 50%, #66bb6a 100%)',
    boxShadow: '0 4px 10px 0 rgba(0,0,0,.25)',
  }),
  ...(ownerState.active && {
    backgroundImage:
      'linear-gradient(136deg,rgb(219, 145, 60) 0%,rgb(235, 160, 47) 50%,rgb(219, 137, 82) 100%)',
      
  }),
}));
function ColorlibStepIcon(props) {
  
    const { active, completed, className } = props;
  
    const icons = {
      1: <DownloadIcon />,
      2: <TableChartIcon />,
      3: <ChatIcon />,
      4: <AssessmentIcon />,
    };
  
    return (
      <ColorlibStepIconRoot
        className={className}
        ownerState={{ active, completed }}
      >
        {icons[String(props.icon)]}
      </ColorlibStepIconRoot>
    );
  }

export default function AppHeader() {
 
  const { theme } = useContext(ThemeContext);
  const activeStep = theme;
  const [open, setOpen] = useState(false);
  const [configOpen, setConfigOpen] = useState(false);

  const toggleDrawer = (state) => () => setOpen(state);
console.log(configOpen)
  const navItems = [
    { text: 'Home', icon: <HomeIcon /> },
    { text: 'Docs', icon: <ArticleIcon /> },
    { text: 'About', icon: <InfoIcon /> }
  ];

  return (
    <>

      <AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 }}>
      <Toolbar sx={{ justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap' }}>
  {/* Left section: Logo + Title */}
  <Box sx={{ display: 'flex', alignItems: 'center' }}>
  {/*   <IconButton edge="start" color="inherit" onClick={toggleDrawer(true)} sx={{ mr: 2 }}>
      <MenuIcon />
    </IconButton>*/}
   

   <CardMedia
   style={{marginRight:"100px", width:"80px"}}
    component="img"
    height="50"
    image={tempImge}
    alt={"alt"}

    sx={{ objectFit: "contain" }}
  />
   
    <Typography style={{marginLeft: "-90px",
    fontFamily: "ui-monospace",
    fontSize: "30px",
    fontWeight: "bold"}} variant="h6" noWrap >

     QUARTA 
    </Typography>
 
  </Box>

  {/* Right or Centered Stepper (Choose layout mode below) */}
  <Box
    sx={{
        paddingTop:'10px',
      flexGrow: 1,
      display: 'flex',
      justifyContent: 'right', // 👉 center it horizontally
      // justifyContent: 'flex-end', // 👉 use this instead to align right
      mt: { xs: 2, sm: 0 },
    }}
  >
  
   
    <Stepper
      activeStep={activeStep}
      alternativeLabel
      connector={<ColorlibConnector />}
      sx={{ maxWidth: '80%', width:"60%" }}
    >
      {steps.map((label, index) => (
        <Step key={label} >
          <StepLabel StepIconComponent={ColorlibStepIcon}>
            <Typography
              variant="caption"
              sx={{
                color: index === activeStep ? 'green' : 'inherit',
                fontWeight: index === activeStep ? 'bold' : 'normal',
              }}
            >
            
            </Typography>
          </StepLabel>
        </Step>
      ))}
    </Stepper>
    <SettingsIcon style={{marginTop:"5px", fontSize:"40px"}} onClick={() => setConfigOpen(true)}></SettingsIcon>
    <ConfigurationModal open={configOpen} onClose={()=> setConfigOpen(false)}></ConfigurationModal>
  </Box>
</Toolbar>

        
      </AppBar>

      <Drawer anchor="left" open={open} onClose={toggleDrawer(false)}>
        <Box
          sx={{ width: drawerWidth }}
          role="presentation"
          onClick={toggleDrawer(false)}
          onKeyDown={toggleDrawer(false)}
        >
          <Typography variant="h6" sx={{ p: 2 }}>
            Navigation
          </Typography>
          <Divider />
          <List>
            {navItems.map((item, index) => (
              <ListItem button key={index}>
                <ListItemIcon>{item.icon}</ListItemIcon>
                <ListItemText primary={item.text} />
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>
    </>
  );
}