import {
    Container,
    Grid,
    FormControl,
    Select,
    MenuItem,
    Checkbox,
    ListItemText,
    Button,
    CircularProgress,
    FormLabel,
    selectClasses
} from '@mui/material';
import React, { useContext, useState } from 'react';
import axios from 'axios';
import _ from 'lodash'; 

import DocResultsTable from './DocResultsTable';
import VerticalStepper from './VerticalStepper';
import ThemeContext from './ThemeContext';

const banks = [
    { name: 'JPMorgan Chase', id: 'JPMorgan',  irUrl: 'https://www.jpmorganchase.com/ir/quarterly-earnings', },
    { name: 'Bank of America', id: 'BankOfAmerica' ,  irUrl: 'https://investor.bankofamerica.com/quarterly-earnings',},
    { name: 'Citibank', id: 'CitiBank', irUrl: 'https://www.citigroup.com/global/investors/quarterly-earnings', },
    { name: 'Wells Fargo', id: 'WellsFargo',  irUrl: 'https://www.wellsfargo.com/about/investor-relations/earnings/' },
    { name: 'Capital One', id: 'CapitalOne',irUrl: 'https://www.capitalone.com/about/investors/events-and-presentations/' },
    { name: 'Synchrony', id: 'Synchrony',irUrl: 'https://investors.synchrony.com/financials/quarterly-results/default.aspx' },
    { name: 'American Express', id: 'amex',irUrl: 'https://ir.americanexpress.com/quarterly-earnings/default.aspx'}
];


//const docTypes = ['Press Release', 'Presentation', 'Supplement', 'Transcript'];

const docTypes = [{name:"Supplement",id:"press"},{name:"Presentation",id:"presentation"},{name:"Press Release",id:"supplement"},{name:"Transcript",id:"Transcript"}]

const attributes = ['Default', 'test', 'test1'];


//const quarters = ['Q1 2025', 'Q1 2024', 'Q2 2024', 'Q3 2024','Q4 2024', 'Q1 2023', 'Q2 2023', 'Q3 2023', 'Q4 2023'];
const quarters = [{name:"Q1 2025",id:"2025Q1",path:'2025/Q1',q_id:"Q12025"},{name:"Q4 2024",id:"2024Q4",path:'2024/Q4',q_id:"Q42024"},{name:"Q3 2024",id:"2024Q3",path:'2024/Q3',q_id:"Q32024"}];


function DocSearchForm() {
    const { theme, setTheme } = useContext(ThemeContext);
    const [selectedBanks, setSelectedBanks] = useState([]);
    const [selectedDocs, setSelectedDocs] = useState([]);
    const [selectedQuarters, setSelectedQuarters] = useState([]);
    const [result, setResult] = useState(null);
    const [loading, setLoading] = useState(false);

    const handleSearch = async () => {
        setTheme(0);
        let bankTempArr = [];
        _.map(selectedBanks,function(bank){
            const obj = _.filter(banks, {name: bank});
            console.log(obj)
            bankTempArr.push(obj[0])
        })
         
        let documentTempArr = [];
        _.map(selectedDocs,function(doc){
            const obj = _.filter(docTypes, {name: doc});
            console.log(obj)
            documentTempArr.push(obj[0])
        })
        let quarterTempArr = [];
        _.map(selectedQuarters,function(quarter){
            const obj = _.filter(quarters, {name: quarter});
            console.log(obj)
            quarterTempArr.push(obj[0])
        })
          console.log(documentTempArr,quarterTempArr,bankTempArr)
        setLoading(true);
        try {
          const res = await axios.post('http://127.0.0.1:5000/discoverDocument', {
            banks: bankTempArr,
            documentTypes: documentTempArr,
            quarter: quarterTempArr,
          });
          setResult(res.data);
          
        } catch (err) {
          console.error('Fetch failed:', err);
         
        } finally {
          setLoading(false);
        }
      };
    return (
        <Container maxWidth={false} disableGutters sx={{ px: 2 }}>
   
   
            <Grid container spacing={2}>
                <Grid item xs={12} sm={12}>
                    <FormControl size="small" fullWidth sx={{ m: 1, width: 300, mt: 3 }}>
                        <FormLabel style={{fontSize:'14px'}}>Bank(s)</FormLabel>
                        <Select
style={{fontSize:'14px'}}
                            multiple
                            value={selectedBanks}
                            onChange={(e) => setSelectedBanks(e.target.value)}
                            renderValue={(selected) => selected.join(', ')}
                        >
                            {banks.map((bank) => (
                                <MenuItem key={bank.id} value={bank.name}>
                                    <Checkbox checked={selectedBanks.includes(bank.name)} />
                                    <ListItemText primary={bank.name} />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>

                <Grid item xs={12} sm={12}>
                    <FormControl size="small" fullWidth sx={{ m: 1, width: 300, mt: 3 }}>
                        <FormLabel style={{fontSize:'14px'}}>Document Type(s)</FormLabel>
                        <Select
                        style={{fontSize:'14px'}}
                            multiple
                            value={selectedDocs}
                            onChange={(e) => setSelectedDocs(e.target.value)}
                            renderValue={(selected) => selected.join(', ')}
                        >
                            {docTypes.map((type) => (
                                <MenuItem key={type} value={type.name}>
                                    <Checkbox checked={selectedDocs.includes(type.name)} />
                                    <ListItemText primary={type.name} />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>

                <Grid item xs={12} sm={4}>
                    <FormControl size="small" fullWidth sx={{ m: 1, width: 300, mt: 3 }}>
                        <FormLabel style={{fontSize:'14px'}}>Quarter(s)</FormLabel>
                        <Select
                        style={{fontSize:'14px'}}
                            multiple
                            value={selectedQuarters}
                            onChange={(e) => setSelectedQuarters(e.target.value)}
                            renderValue={(selected) => selected.join(', ')}
                        >
                            {quarters.map((q) => (
                                <MenuItem key={q} value={q.name}>
                                    <Checkbox checked={selectedQuarters.includes(q.name)} />
                                    <ListItemText primary={q.name} />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
                
                <Grid item xs={12} sm={4}>
                <FormControl size="small" fullWidth sx={{ m: 1, width: 150, mt: 3 , paddingTop:2.5}}>
               
                    <Button
                        fullWidth
                        variant="contained"
                        onClick={handleSearch}
                        disabled={
                            !selectedBanks.length || !selectedDocs.length || !selectedQuarters.length || loading
                        }
                    >
                        {loading ? <CircularProgress size={24} /> : '🔍 Search'}
                    </Button>

</FormControl>
                   
                      
                   
                </Grid>
               
            </Grid>
          

            {result?.length > 0 && (
  <DocResultsTable results={result} selectedBanks={selectedBanks} selectedDocs={selectedDocs} selectedQuarters={selectedQuarters} banks={banks} quarters={quarters}/>
  
)}         


        </Container>
    );
}

export default DocSearchForm;
