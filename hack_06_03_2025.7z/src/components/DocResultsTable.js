import React, { useContext, useState } from 'react';
import {
  Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Paper, Typography, Button, CircularProgress
} from '@mui/material';
import CloudDownloadIcon from '@mui/icons-material/CloudDownload';
import ViewComfyAltIcon from '@mui/icons-material/ViewComfyAlt';

import { styled } from '@mui/material/styles';
import axios from 'axios';
import ArchiveIcon from '@mui/icons-material/Archive';
import _ from 'lodash'; 
import ThemeContext from './ThemeContext';

const VisuallyHiddenInput = styled('input')({
  clip: 'rect(0 0 0 0)',
  clipPath: 'inset(50%)',
  height: 1,
  overflow: 'hidden',
  position: 'absolute',
  bottom: 0,
  left: 0,
  whiteSpace: 'nowrap',
  width: 1,
});
function DocResultsTable({ results, selectedBanks, selectedDocs,selectedQuarters,banks,quarters }) {
  const { theme, setTheme } = useContext(ThemeContext);
        const [searchResult, setSearchResult] = useState(results);
        const [downlaodResult, setDownloadResult] = useState(null);
        const [extractResult, setExtractResult] = useState(null);
        const [loading, setLoading] = useState(false);
        const [loadingDownload, setLoadingDownload] = useState(false);
        const [html, setHTML] = useState({__html: ""});
  if (!results?.length) {
    return <Typography>No results available.</Typography>;
  }

  const handleDownload = async () => {
    setLoadingDownload(true);
          try {
            const res = await axios.post('http://127.0.0.1:5000/downloadDocuments', results);
            setDownloadResult(res.data);
            const _result = _.cloneDeep(searchResult);
            _.map(res.data,function(obj){
                const index = _.findIndex(_result,{bankid:obj.bankid})
                if(index!== -1){
                  _.set(_result[index],"status",obj.status)
                }
            })
            setTheme(1);
           setSearchResult(_result);
           setLoadingDownload(false);
          } catch (err) {
            console.error('Fetch failed:', err);
           
           
          } finally {
            setLoadingDownload(false);
          }
        };

        
        // const handleExtract = async () => {
        //   setLoading(true);
        //   try {
        //     const res = await axios.post('http://192.168.48.209:5000/api/analyze', {
        //       banks: selectedBanks,
        //       docTypes: selectedDocs,
        //       quarters: selectedQuarters,
        //     });
        //     setExtractResult(res.data);
        //   } catch (err) {
        //     console.error('Fetch failed:', err);
            
        //   } finally {
        //     setLoading(false);
        //   }
        // };

        const handleExtract = async () => {
          setTheme(2);
          setLoading(true);
          let bankTempArr = [];
          _.map(selectedBanks,function(bank){
              const obj = _.filter(banks, {name: bank});
              console.log(obj)
              bankTempArr.push(obj[0].id)
          })
           
          // let documentTempArr = [];
          // _.map(selectedDocs,function(doc){
          //     const obj = _.filter(docTypes, {name: doc});
          //     console.log(obj)
          //     documentTempArr.push(obj[0])
          // })
          let quarterTempArr = [];
          _.map(selectedQuarters,function(quarter){
              const obj = _.filter(quarters, {name: quarter});
              console.log(obj)
              quarterTempArr.push(obj[0].q_id)
          })
            console.log(quarterTempArr,bankTempArr)
          setLoading(true);
          
          try {
            const res = await axios.post('http://192.168.48.209:5000/api/analyze', {
              bank_names: bankTempArr,
             // documentTypes: documentTempArr,
              quarter: quarterTempArr,
            });
            console.log(res.data)
           // setResult(res.data);
           setExtractResult(res.data.report_htm)
           setHTML(res.data.report_html)
           setLoading(false);
           setTheme(4);
          } catch (err) {
            console.error('Fetch failed:', err);

          } finally {
            setLoading(false);
          }
        };
        function getColor(status){
          let str =  "error" // ? 'success' : 'error'"
          if(status === 'found'){
            str = 'success';
          }
          else if(status == "downloaded"){
            str = 'info';
          }else{
            str = "error"
          }
          return str
        }

  return (
      <div>
     
    <TableContainer component={Paper} sx={{ mt: 3 }}>
      <Table>
        <TableHead style={{backgroundColor:'rgb(232 241 250)'}}>
          <TableRow>
          <TableCell style={{padding:'10px' , textAlign:'center'}}><strong> Download</strong></TableCell>
            <TableCell style={{padding:'10px', textAlign:'center'}}><strong>Bank Name</strong></TableCell>
            <TableCell style={{padding:'10px', textAlign:'center'}}><strong>Document Type</strong></TableCell>
            <TableCell style={{padding:'10px', textAlign:'center'}}><strong>Quarter </strong></TableCell>
            <TableCell style={{padding:'10px', textAlign:'center'}} ><strong>Status</strong></TableCell>
           
            <TableCell style={{padding:'10px', textAlign:'center'}}><strong>🌐 View Source</strong></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {searchResult.map((doc) => (
            <TableRow key={doc.id}>
               <TableCell style={{padding:'10px', textAlign:'center'}}>
                {doc.status === 'found'  || doc.status === 'downloaded' ? (
                  <CloudDownloadIcon
                  style={{cursor:'pointer'}}
                    size="small"
                    variant="contained"
                    color="primary"
                    href={doc.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e)=>{window.open(doc.url)}}
                  >
                   
                  </CloudDownloadIcon>
                ) : (
                  <CloudDownloadIcon size="small" variant="contained" disabled >
                   
                  </CloudDownloadIcon>
                )}
              </TableCell>
              <TableCell style={{padding:'10px', textAlign:'center'}}> {doc.name}</TableCell>
              <TableCell style={{padding:'10px', textAlign:'center'}}> {doc.docType}</TableCell>
              <TableCell style={{padding:'10px', textAlign:'center'}}> {doc.quarter}</TableCell>

              <TableCell style={{padding:'10px', textAlign:'center'}}>
                <Button
                style={{fontSize:'10px', borderRadius:'20px'}}
                  size="small"
                  variant="contained"
                  color={getColor(doc.status )}
                  
                >
                  {doc.status.toUpperCase()}
                </Button>
              </TableCell>

             

              <TableCell style={{padding:'10px', textAlign:'center'}}>
                {doc.status === 'found' ? (
                  <ViewComfyAltIcon
                  style={{cursor:'pointer'}}
                    size="small"
                    variant="contained"
                    color="primary"
                    href={doc.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e)=>{window.open(doc.url)}}
                  >
                    View
                  </ViewComfyAltIcon>
                ) : (
                  <ViewComfyAltIcon size="small" variant="contained" >
                    N/A
                  </ViewComfyAltIcon>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    <Button style={{marginTop:'20px'}}
    disabled={
      downlaodResult || loadingDownload}
    onClick={handleDownload}
      component="label"
      role={undefined}
      variant="contained"
      tabIndex={-1}
      startIcon={<CloudDownloadIcon />}
    >
      
      {loadingDownload ? <CircularProgress size={24} />  : 'Download All'}
      
    </Button>
    <Button style={{marginTop:'20px', marginLeft:'10px'}}
     disabled={
      extractResult || loading}
    onClick={handleExtract}
      component="label"
      role={undefined}
      variant="contained"
      tabIndex={-1}
      startIcon={<ArchiveIcon></ArchiveIcon>}
    >
      
      {loading ? <div><CircularProgress size={20} /> Report Is Loading.......</div> : 'Extract Attributes'}
      
    </Button>
    
      </div>
  );
}

export default DocResultsTable;
