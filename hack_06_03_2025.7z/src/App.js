import React from 'react';
import { Box } from '@mui/material';
import AppHeader from './components/AppHeader';

import VerticalStepper from './components/VerticalStepper';
import DocSearchForm from './components/DocSearchForm';
import ThemeProvider from './components/ThemeProvider';

import ChatBotPopup from './components/ChatBotPopup';


function App() {
  return (
    <ThemeProvider>
    <Box>
      <AppHeader />
      <Box sx={{ p: 3, mt: 8 }}>
      <DocSearchForm></DocSearchForm>
      <ChatBotPopup></ChatBotPopup>
      </Box>
    </Box>
    </ThemeProvider>
  );
}

export default App;
